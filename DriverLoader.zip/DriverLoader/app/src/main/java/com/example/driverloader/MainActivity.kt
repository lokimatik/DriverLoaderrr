package com.example.driverloader

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.topjohnwu.superuser.Shell
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            Shell.setDefaultBuilder(
                Shell.Builder.create().setFlags(Shell.FLAG_REDIRECT_STDERR)
            )
        }
        private const val TMP_DIR = "/data/local/tmp"
        // Yalnızca güvenli karakterlere izin ver (shell enjeksiyonunu önler)
        private val SAFE_PARAMS = Regex("^[A-Za-z0-9_=,.:/\\- ]*$")
    }

    private lateinit var log: TextView
    private lateinit var paramsInput: EditText
    private var loadedModule: String? = null

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) prepareModule(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        paramsInput = EditText(this).apply {
            hint = "Modül parametreleri (isteğe bağlı): param=değer"
            setSingleLine()
        }
        val pick = Button(this).apply { text = "Sürücü (.ko) seç ve yükle" }
        val unload = Button(this).apply { text = "Son yüklenen modülü kaldır" }
        val list = Button(this).apply { text = "Yüklü modülleri listele" }
        val dmesg = Button(this).apply { text = "Çekirdek günlüğü (dmesg)" }
        log = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }

        listOf(paramsInput, pick, unload, list, dmesg).forEach { root.addView(it) }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)

        pick.setOnClickListener {
            Shell.getShell { shell ->
                if (!shell.isRoot) append("Root erişimi verilmedi.")
                else picker.launch(arrayOf("*/*"))
            }
        }
        unload.setOnClickListener { unloadModule() }
        list.setOnClickListener { run("lsmod") }
        dmesg.setOnClickListener { run("dmesg | tail -n 30") }
    }

    /** Dosyayı kopyalar, vermagic'i kernel sürümüyle karşılaştırır, sonra yükler. */
    private fun prepareModule(uri: Uri) {
        val params = paramsInput.text.toString().trim()
        if (!SAFE_PARAMS.matches(params)) {
            append("Hata: parametrelerde izin verilmeyen karakter var.")
            return
        }
        Thread {
            val name = displayName(uri) ?: "module.ko"
            if (!name.endsWith(".ko")) {
                append("Hata: yalnızca .ko dosyası seçin.")
                return@Thread
            }
            val cached = File(cacheDir, name)
            contentResolver.openInputStream(uri)?.use { input ->
                cached.outputStream().use { input.copyTo(it) }
            }

            val vermagic = readVermagic(cached)
            val kernel = Shell.cmd("uname -r").exec().out.firstOrNull()?.trim().orEmpty()
            append("Kernel: $kernel\nModül vermagic: ${vermagic ?: "bulunamadı"}")

            val compatible = vermagic != null && vermagic.startsWith(kernel)
            if (compatible) {
                doInsmod(cached, name, params)
            } else {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Sürüm uyuşmuyor")
                        .setMessage(
                            "Modül bu kernel için derlenmemiş görünüyor.\n\n" +
                            "Kernel: $kernel\nModül: ${vermagic ?: "bilinmiyor"}\n\n" +
                            "Yine de yüklemeyi denemek ister misin?"
                        )
                        .setPositiveButton("Yine de yükle") { _, _ ->
                            Thread { doInsmod(cached, name, params) }.start()
                        }
                        .setNegativeButton("İptal") { _, _ -> cached.delete() }
                        .show()
                }
            }
        }.start()
    }

    private fun doInsmod(cached: File, name: String, params: String) {
        val dest = "$TMP_DIR/$name"
        val result = Shell.cmd(
            "cp '${cached.absolutePath}' '$dest'",
            "chmod 644 '$dest'",
            "insmod '$dest' $params"
        ).exec()

        if (result.isSuccess) {
            loadedModule = name.removeSuffix(".ko").replace('-', '_')
            append("Yüklendi: $name")
        } else {
            append("Yükleme başarısız (kod ${result.code}):\n${result.out.joinToString("\n")}")
            run("dmesg | tail -n 10")
        }
        Shell.cmd("rm -f '$dest'").submit()
        cached.delete()
    }

    private fun unloadModule() {
        val mod = loadedModule
        if (mod == null) { append("Kaldırılacak modül yok."); return }
        Thread {
            val r = Shell.cmd("rmmod $mod").exec()
            append(if (r.isSuccess) "Kaldırıldı: $mod" else "Hata: ${r.out.joinToString("\n")}")
            if (r.isSuccess) loadedModule = null
        }.start()
    }

    private fun run(cmd: String) {
        Thread {
            val r = Shell.cmd(cmd).exec()
            append(r.out.joinToString("\n").ifBlank { "(çıktı yok)" })
        }.start()
    }

    /** .ko dosyasındaki "vermagic=" satırını okur. */
    private fun readVermagic(file: File): String? {
        val bytes = file.readBytes()
        val key = "vermagic=".toByteArray()
        outer@ for (i in 0..bytes.size - key.size) {
            for (j in key.indices) if (bytes[i + j] != key[j]) continue@outer
            var end = i + key.size
            while (end < bytes.size && bytes[end] != 0.toByte()) end++
            return String(bytes, i + key.size, end - (i + key.size))
        }
        return null
    }

    private fun displayName(uri: Uri): String? =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        }

    private fun append(text: String) = runOnUiThread { log.append(text + "\n\n") }
}
